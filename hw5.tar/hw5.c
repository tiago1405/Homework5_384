#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <unistd.h>
#include <sys/inotify.h>

int main (int argc, char* argv[])
{
	bool opt_h, opt_d, opt_m, opt_t;									//Creating variables and initialzing them
	opt_h = false;	opt_m = false;
	opt_d = false;	opt_t = false;
	char* direc = NULL;

	int opt;
	while((opt = getopt(argc, argv, "hd:mt")) != -1)					// Command line opts
	{
		switch(opt)
		{
			case 'h':	opt_h = true;					break;
			case 'd':	opt_d = true; direc = optarg;	break;
			case 'm':	opt_d = true;					break;
			case 't':	opt_t = true; 					break;
		}
	}
	
	if(opt_h == true)													// Print help info and successfully 
	{																	// terminate after
		printf("Write helpful information to the user \n");
		printf("Write helpful information to the user \n");
		exit(EXIT_SUCCESS);
	}
	
	char* path = "/home/tiago/Documents/dummy";							// Costumize the directory path
	if(opt_d == true)
	{
		path = direc;
	}

	int filed = inotify_init();											// Creating filed descriptor
	int fwatch = inotify_add_watch(filed, path, IN_MODIFY | IN_ACCESS);	// Creting file watcher
	while(1)
	{
		size_t length = (5120);											// 5kb size
		char buf[length];
		int reader = read(filed, buf, length);
		char* i;

		for(i = buf; i < buf + reader;)									// Keep reading
		{
			struct inotify_event* event = (struct inotify_event*)i;		//	Creating event notifier

			if(event->mask == 2)										// If the file was modified
			{
				// Here we copy the file

			}
		}
	}

	return EXIT_SUCCESS;
}